import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter, MultipleLocator
# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['ENERGY', 'FLUX']
    return df

# File paths
Iron = {
    'Input_Flux': r"D:\mnit summer\22 june\flux\fluence-vs.-energy-vs.-isotope-vs.-depth-iron input spe.csv",
    'Output_Flux': r"D:\mnit summer\22 june\flux\fluence-vs.-energy-vs.-isotope-vs.-depth-iron output spe.csv",
}

Proton = {
    'Input_Flux': r"D:\mnit summer\22 june\flux\fluence-vs.-energy-vs.-isotope-vs.-depth-proton input PE.csv",
    'Output_Flux': r"D:\mnit summer\22 june\flux\fluence-vs.-energy-vs.-isotope-vs.-depth-proton out pe spe.csv",
}

# Styling dictionaries
markers = {'Input_Flux': 'o', 'Output_Flux': 's'}
colors = {'Input_Flux': 'red', 'Output_Flux': 'green'}

# Create subplots
fig, axs = plt.subplots(1, 2, figsize=(14, 6))

# Plot Proton flux vs energy
for label, path in Proton.items():
    df = load_data(path)

    axs[0].plot(
        np.log10(df['ENERGY']),
        np.log10(df['FLUX']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=f'Proton {label.replace("_", " ")}'
    )

axs[0].set_title('Proton Flux vs Energy', fontsize=20)

axs[0].set_xlabel('Energy in MeV/n', fontsize=20)

axs[0].set_ylabel(
    r'Flux in cm$^{-2}$ day$^{-1}$ (MeV/n)$^{-1}$ ',
    fontsize=20
)

# Convert x-axis ticks to 10^n
axs[0].xaxis.set_major_formatter(
    FuncFormatter(lambda x, _: r'$10^{%d}$' % x)
)

# Convert y-axis ticks to 10^n
axs[0].yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: r'$10^{%d}$' % y)
)

axs[0].legend(fontsize=20)
axs[0].grid(True)

axs[0].tick_params(axis='x', labelsize=18)
axs[0].tick_params(axis='y', labelsize=18)

# Plot Iron flux vs energy
for label, path in Iron.items():
    df = load_data(path)

    axs[1].plot(
        np.log10(df['ENERGY']),
        np.log10(df['FLUX']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=f'Iron {label.replace("_", " ")}'
    )

axs[1].set_title('Iron Flux vs Energy', fontsize=20)

axs[1].set_xlabel('Energy in MeV/n', fontsize=20)

axs[1].set_ylabel(
    r'Flux in cm$^{-2}$ day$^{-1}$ (MeV/n)$^{-1}$',
    fontsize=20
)

# Major ticks every 1 decade
axs[1].yaxis.set_major_locator(MultipleLocator(1))

# Show as 10^x
axs[1].yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: rf'$10^{{{y:.0f}}}$')
)

# Convert y-axis ticks to 10^n
axs[1].yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: r'$10^{%d}$' % y)
)

axs[1].legend(fontsize=20)
axs[1].grid(True)

axs[1].tick_params(axis='x', labelsize=18)
axs[1].tick_params(axis='y', labelsize=18)

plt.tight_layout()
plt.show()