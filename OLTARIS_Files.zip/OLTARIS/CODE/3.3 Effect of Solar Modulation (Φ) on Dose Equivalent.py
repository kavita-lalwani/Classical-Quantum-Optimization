import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# File paths
material = {
    'POLY': 'D:\\mnit summer\\Copy of PE PHI CHANGE1.xlsx',
    'LiH': 'D:\\mnit summer\\Copy of LiH phi change1.xlsx',
    'AL': 'D:\\mnit summer\\Copy of AL PHI CHANGE1.xlsx'
}

# Read Excel files
df1 = pd.read_excel(material['AL'])
df2 = pd.read_excel(material['POLY'])
df3 = pd.read_excel(material['LiH'])

# Rename columns if needed
df1.columns = ['phi', 'dose eq', 'depth']
df2.columns = ['phi', 'dose eq', 'depth']
df3.columns = ['phi', 'dose eq', 'depth']

# Plotting
plt.figure(figsize=(8, 6))
plt.plot(df1['phi'], df1['dose eq'], marker='s', linestyle='--', color='pink', label='Aluminum')
plt.plot(df2['phi'], df2['dose eq'], marker='o', linestyle='-', color='c', label='Polyethylene')
plt.plot(df3['phi'], df3['dose eq'], marker='x', linestyle='--', color='gray', label='Lithium hydride')

plt.xlabel('Solar Modulation (Φ) in MV', fontsize=20)
plt.ylabel('Dose Equivalent Rate in mSv/day', fontsize=20)  
plt.title('Dose Equivalent Rate Variation with Solar Modulation', fontsize=20)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

plt.legend(fontsize=20)  
plt.grid(True)
plt.tight_layout()
plt.show()
