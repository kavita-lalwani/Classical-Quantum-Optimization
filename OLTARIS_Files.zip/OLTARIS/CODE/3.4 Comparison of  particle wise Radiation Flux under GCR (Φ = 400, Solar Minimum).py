import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

# Function to load and clean data
# GCR
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['ENERGY', 'FLUX']
    return df

# File paths
fe_56 = {
    'Input_Flux': r'D:\mnit summer\22 june\flux-vs.-energy-vs.-isotope-vs.-depth-fe inputflux PE.csv',
    'Output_Flux': r'D:\mnit summer\22 june\flux-vs.-energy-vs.-isotope-vs.-depth-Fe outflux PE.csv',
}

Proton = {
    'Input_Flux': r'D:\mnit summer\22 june\flux-vs.-energy-vs.-isotope-vs.-depth-proton influx PE.csv',
    'Output_Flux': r'D:\mnit summer\22 june\flux-vs.-energy-vs.-isotope-vs.-depth- proton outflux PE.csv',
}

# Styling dictionaries
markers = {'Input_Flux': 'o', 'Output_Flux': 's'}
colors = {'Input_Flux': 'red', 'Output_Flux': 'green'}

# Create subplots
fig, axs = plt.subplots(1, 2, figsize=(14, 6))

# Plot Proton flux vs energy
for label, path in Proton.items():
    df = load_data(path)

    axs[0].plot(
        np.log10(df['ENERGY']),
        np.log10(df['FLUX']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=f'Proton {label.replace("_", " ")}'
    )

axs[0].set_title('Proton Flux vs Energy', fontsize=20)

axs[0].set_xlabel('Kinetic Energy in MeV/n ', fontsize=20)

axs[0].set_ylabel(
    r'Flux in cm$^{-2}$ day$^{-1}$ (MeV/n)$^{-1}$',
    fontsize=20
)

# Convert x-axis ticks to 10^n
axs[0].xaxis.set_major_formatter(
    FuncFormatter(lambda x, _: r'$10^{%d}$' % x)
)

# Convert y-axis ticks to 10^n
axs[0].yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: r'$10^{%d}$' % y)
)

axs[0].legend(fontsize=20)
axs[0].grid(True)

axs[0].tick_params(axis='x', labelsize=16)
axs[0].tick_params(axis='y', labelsize=16)

# Plot Fe-56 flux vs energy
for label, path in fe_56.items():
    df = load_data(path)

    axs[1].plot(
        np.log10(df['ENERGY']),
        np.log10(df['FLUX']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=f'Iron {label.replace("_", " ")}'
    )

axs[1].set_title('Iron Flux vs Energy', fontsize=20)

axs[1].set_xlabel('Kinetic Energy in MeV/n', fontsize=20)

axs[1].set_ylabel(
    r'Flux in cm$^{-2}$ day$^{-1}$ (MeV/n)$^{-1}$',
    fontsize=20
)

# Convert x-axis ticks to 10^n
axs[1].xaxis.set_major_formatter(
    FuncFormatter(lambda x, _: r'$10^{%d}$' % x)
)

# Convert y-axis ticks to 10^n
axs[1].yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: r'$10^{%d}$' % y)
)

axs[1].legend(fontsize=20)
axs[1].grid(True)

axs[1].tick_params(axis='x', labelsize=16)
axs[1].tick_params(axis='y', labelsize=16)

plt.tight_layout()
plt.show()