import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress
from matplotlib.ticker import FuncFormatter

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose equivalent', 'depth mod']
    return df

# File paths
SPE_Proton = {
    'Aluminum': r"D:\mnit summer\eqivalent does\dose-equivalent-(msv)-vs.-depth-proton AL.csv",
    'Polyethylene': r"D:\mnit summer\eqivalent does\dose-equivalent-(msv)-vs.-depth-proton PE.csv",
    'Lithium hydride': r"D:\mnit summer\eqivalent does\dose-equivalent-(msv)-vs.-depth-(cm) proton LiH.csv",
    'Lithium borohydride': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth proton LiB.csv",
    'Ammoniotrihydroborate': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth-proton ammo.csv",
    'Beryllium borohydride': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth-Beryllium_borohydride_proton spe.csv"
}

# Styling
markers = {
    'Aluminum': 'o',
    'Polyethylene': '^',
    'Lithium hydride': 'x',
    'Lithium borohydride': 'o',
    'Ammoniotrihydroborate': 'x',
    'Beryllium borohydride': 's'
}

colors = {
    'Aluminum': 'pink',
    'Polyethylene': 'c',
    'Lithium hydride': 'gray',
    'Lithium borohydride': 'red',
    'Ammoniotrihydroborate': 'purple',
    'Beryllium borohydride': 'blue'
}

# Create plot
plt.figure(figsize=(8, 6))

# Plot and slope calculation
for label, path in SPE_Proton.items():

    df = load_data(path)

    depth = df['depth mod']

    dose_log = np.log10(df['dose equivalent'])

    # Plot the data
    plt.plot(
        depth,
        dose_log,
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=label
    )

# Labels and title
plt.xlabel('Thickness in g/cm²', fontsize=20)

plt.ylabel('Proton Dose Equivalent Rate in mSv/day', fontsize=19)

plt.title('Proton Dose Equivalent Rate', fontsize=20)

# Convert y-axis ticks to 10^n format
plt.gca().yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: rf'$10^{{{y:.0f}}}$')
)

plt.legend(fontsize=14)

# Axis tick formatting
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

plt.grid(True)

plt.tight_layout()
plt.show()