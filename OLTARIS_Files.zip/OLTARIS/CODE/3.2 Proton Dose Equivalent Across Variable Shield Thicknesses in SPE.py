import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose equivalent', 'depth mod']
    return df

# File paths for October 1989 SPE
OCT_1989 = {
    'Aluminium': r'D:\mnit summer\12 june\dose-equivalent-(msv)-vs.-depth-(cm)-(by-particle-type)_SPE_OCT_AL.csv',

    'Polyethylene': r'D:\mnit summer\12 june\dose-equivalent-(msv)-vs.-depth-(cm)-(by-particle-type)_SPE_OCT_PE.csv',

    'Lithium hydride': r'D:\mnit summer\12 june\dose-equivalent-(msv)-vs.-depth-(cm)-(by-particle-type)_SPE_OCT_LIH.csv',
}

# Styling dictionaries
markers = {
    'Polyethylene': 'o',
    'Aluminium': 's',
    'Lithium hydride': 'x'
}

colors = {
    'Polyethylene': 'c',
    'Aluminium': 'pink',
    'Lithium hydride': 'gray'
}

# Create a single plot
plt.figure(figsize=(8, 6))

# Plot October 1989 SPE data
for label, path in OCT_1989.items():
    df = load_data(path)

    plt.plot(
        df['depth mod'],
        np.log10(df['dose equivalent']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=label
    )

# Labels and formatting

# Labels and title
plt.xlabel('Thickness in g/cm²', fontsize=20)
plt.ylabel('Proton Dose Equivalent Rate in mSv/day', fontsize=20)
plt.title('Proton Dose Equivalent Rate', fontsize=20)
 


# Convert y-axis tick labels to 10^n format
plt.gca().yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: r'$10^{%d}$' % y)
)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

plt.legend(fontsize=18) 
plt.grid(True)

plt.tight_layout()
plt.show()