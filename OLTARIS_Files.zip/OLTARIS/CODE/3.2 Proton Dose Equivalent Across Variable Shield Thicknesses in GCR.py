import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose equivalent', 'depth mod']  
    return df

# Solar Minima (φ = 400) File paths
SOLAR_MIN = {
    'Aluminium': r'D:\mnit summer\12 june\dose-equivalent-(msv_day)-vs.-depth-(cm)-(by-particle-type)proton__400_AL.csv',
    'Polyethylene': r'D:\mnit summer\12 june\dose-equivalent-(msv_day)-vs.-depth-(cm)-(by-particle-type)_PE_400.csv',
    'Lithium hydride': r'D:\mnit summer\12 june\dose-equivalent-(msv_day)-vs.-depth-(cm)-(by-particle-type)_LiH_400.csv',
}

# Styling dictionaries
markers = { 'Polyethylene': 'o','Aluminium': 's', 'Lithium hydride': 'x'}
colors = {'Polyethylene': 'c','Aluminium': 'pink', 'Lithium hydride': 'gray'}

# Create a single plot
plt.figure(figsize=(8, 6))

# Plot Solar Minima data
for label, path in SOLAR_MIN.items():
    df = load_data(path)
    plt.plot(df['depth mod'], df['dose equivalent'],
             marker=markers[label], linestyle='-', 
             color=colors[label], label=label)

# Labels and title
plt.xlabel('Thickness in g/cm²', fontsize=20)
plt.ylabel('Proton Dose Equivalent Rate in mSv/day', fontsize=20)
plt.title('Proton Dose Equivalent Rate', fontsize=20)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

plt.legend(fontsize=18)  

plt.grid(True)
plt.tight_layout()
plt.show()
