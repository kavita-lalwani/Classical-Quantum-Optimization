import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose', 'depth mod']
    return df

# File paths for Solar Minima (GCR)
solar_min = {
    'Aluminium': "D:\\mnit summer\\AL GALACTIC\\dose-equivalent-(msv_day)-vs.-depth-AL.csv",
        'Polyethylene': "D:\\mnit summer\\galactic 15\\dose-equivalent-(msv_day)-vs.-depth-(cm) PE.csv",

    'Lithium hydride':"D:\\mnit summer\\LiH galatic\\dose-equivalent-(msv_day)-vs.-depth-(cm) LiH.csv"

}
# Styling dictionaries
markers = {'Polyethylene': 'o', 'Aluminium': 's', 'Lithium hydride': '_'}
colors = {'Polyethylene': 'c','Aluminium':'pink', 'Lithium hydride': 'gray'}
linestyles = {'Polyethylene': '-', 'Aluminium': '--', 'Lithium hydride': '--'}

# Create plot
plt.figure(figsize=(8, 6))

# Plot Solar Minima data
for label, path in solar_min.items():
    df = load_data(path)
    plt.plot(df['depth mod'], df['dose'], 
             marker=markers[label], linestyle=linestyles[label], 
             color=colors[label], label=label)

# Add plot labels and formatting
plt.title('Dose Equivalent Rate', fontsize=20)
plt.xlabel('Thickness in g/cm²', fontsize=20)
plt.ylabel('Dose Equivalent Rate in mSv/day', fontsize=20)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend(fontsize=20)  

plt.grid(True)
plt.tight_layout()
plt.show()

