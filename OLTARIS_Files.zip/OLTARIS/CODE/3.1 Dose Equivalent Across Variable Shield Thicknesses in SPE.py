import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import LogFormatterMathtext

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose', 'depth mod']
    return df

# File paths for SPE
SPE = {
    'Aluminium': "D:\\mnit summer\\22 june\\dose-equivalent-(msv)-vs.-depthSOLAR AL.csv",
    'Polyethylene': "D:\\mnit summer\\22 june\\dose-equivalent-(msv)-vs.-depth-SOLAR PE.csv",
    'Lithium hydride': "D:\\mnit summer\\22 june\\dose-equivalent-(msv)-vs.-depthSOLAR LIH.csv"
}

# Styling dictionaries
markers = {
    'Polyethylene': 'o',
    'Aluminium': 's',
    'Lithium hydride': '_'
}

colors = {
    'Polyethylene': 'c',
    'Aluminium': 'pink',
    'Lithium hydride': 'gray'
}

linestyles = {
    'Polyethylene': '-',
    'Aluminium': '--',
    'Lithium hydride': '--'
}

# Create plot
plt.figure(figsize=(8, 6))

# Plot SPE data
for label, path in SPE.items():
    df = load_data(path)

    plt.plot(
        df['depth mod'],
        df['dose'],
        marker=markers[label],
        linestyle=linestyles[label],
        color=colors[label],
        label=label
    )

# Logarithmic y-axis
plt.yscale('log')

# Format ticks as 10^n
plt.gca().yaxis.set_major_formatter(LogFormatterMathtext())

# Labels and title
plt.title('Dose Equivalent Rate', fontsize=20)

plt.xlabel('Thickness in g/cm²', fontsize=20)

# Corrected unit
plt.ylabel('Dose Equivalent rate in mSv/day', fontsize=20)

plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

plt.legend(fontsize=20)
plt.grid(True)

plt.tight_layout()
plt.show()