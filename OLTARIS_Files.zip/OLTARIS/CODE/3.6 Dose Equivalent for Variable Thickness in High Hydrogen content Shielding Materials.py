import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FuncFormatter

# Function to load and clean data
def load_data(path):
    df = pd.read_csv(path)
    df.columns = ['depth', 'dose equivalent', 'depth mod']
    return df

# SPE File paths
SPE = {
    'Aluminum': r"D:\mnit summer\AL solar\dose-equivalent-(msv)-vs.-depth-(cm).csv",
    'Polyethylene': r"D:\mnit summer\solar 15\dose-equivalent-(msv)-vs.-depth-(cm)_PE.csv",
    'Lithium hydride': r"D:\mnit summer\LiH solar\dose-equivalent-(msv)-vs.-depth-(cm).csv",
    'Lithium borohydride': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth-LiB.csv",
    'Ammoniotrihydroborate': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth-ammoniotrihydroborate.csv",
    'Beryllium borohydride': r"D:\mnit summer\22 june\dose-equivalent-(msv)-vs.-depth-Beryllium_borohydride_total.csv"
}

# Styling dictionaries
markers = {
    'Aluminum': 'o',
    'Polyethylene': '^',
    'Lithium hydride': 'x',
    'Lithium borohydride': 'o',
    'Ammoniotrihydroborate': 'x',
    'Beryllium borohydride': 's'
}

colors = {
    'Aluminum': 'pink',
    'Polyethylene': 'c',
    'Lithium hydride': 'gray',
    'Lithium borohydride': 'red',
    'Ammoniotrihydroborate': 'purple',
    'Beryllium borohydride': 'blue'
}

# Create a single plot
plt.figure(figsize=(8, 6))

# Plot Solar Minima data
for label, path in SPE.items():
    df = load_data(path)

    plt.plot(
        df['depth mod'],
        np.log10(df['dose equivalent']),
        marker=markers[label],
        linestyle='-',
        color=colors[label],
        label=label
    )

# Labels and title
plt.xlabel('Thickness in g/cm²', fontsize=20)

plt.ylabel('Dose Equivalent Rate in mSv/day', fontsize=19)

plt.title('Dose Equivalent Rate', fontsize=20)

# Convert y-axis ticks to 10^n format
plt.gca().yaxis.set_major_formatter(
    FuncFormatter(lambda y, _: rf'$10^{{{y:.0f}}}$')
)

plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

plt.legend(fontsize=18)

plt.grid(True)

plt.tight_layout()
plt.show()